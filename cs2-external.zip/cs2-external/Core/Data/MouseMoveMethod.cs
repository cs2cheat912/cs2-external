namespace CS2Cheat.Core.Data;

public enum MouseMoveMethod
{
    TryMouseMoveOld,
    TryMouseMoveNew
}